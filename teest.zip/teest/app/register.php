<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dob').datepicker({ dateFormat: 'yy-mm-dd' });

            $('#job_search').change(function() {
                if ($(this).is(':checked')) {
                    $('#resume').show();
                } else {
                    $('#resume').hide();
                }
            });

            $("#registrationForm").validate({
                rules: {
                    full_name: "required",
                    email: {
                        required: true,
                        email: true
                    },
                    phone: {
                        required: true,
                        digits: true,
                        maxlength: 10
                    },
                    gender: "required",
                    dob: "required",
                    profile_photo: {
                        required: true,
                        extension: "jpg|png"
                    },
                    skills: "required",
                    password: {
                        required: true,
                        minlength: 8,
                        pwcheck: true
                    },
                    confirm_password: {
                        required: true,
                        equalTo: "#password"
                    },
                    resume: {
                        required: "#job_search:checked",
                        extension: "pdf|doc"
                    }
                },
                messages: {
                    email: "Please enter a valid email address",
                    phone: "Please enter a valid phone number",
                    password: {
                        pwcheck: "Password must contain at least one number, one alphabet, and one special character"
                    }
                }
            });

            $.validator.addMethod("pwcheck", function(value) {
                return /[A-Z]/.test(value) && /[0-9]/.test(value) && /[\W]/.test(value);
            });
        });
    </script>
</head>
<body>
    <form id="registrationForm" method="post" enctype="multipart/form-data">
        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name"><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone"><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="male">
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="female">
        <label for="female">Female</label><br>

        <label for="dob">Date of Birth:</label>
        <input type="text" id="dob" name="dob"><br>

        <label for="profile_photo">Profile Photo:</label>
        <input type="file" id="profile_photo" name="profile_photo" accept="image/jpeg, image/png"><br>

        <label for="job_search">Job Search:</label>
        <input type="checkbox" id="job_search" name="job_search"><br>

        <label for="resume" style="display:none">Upload Resume:</label>
        <input type="file" id="resume" name="resume" accept="application/pdf, application/msword" style="display:none"><br>

        <label for="skills">Skills:</label>
        <select id="skills" name="skills[]" multiple>
            <option value="html">HTML</option>
            <option value="css">CSS</option>
            <option value="react">React</option>
            <option value="javascript">JavaScript</option>
            <option value="php">PHP</option>
            <option value="node">Node</option>
            <option value="ajax">Ajax</option>
        </select><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password"><br>

        <button type="submit">Register</button>
    </form>
</body>
</html>
