<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="password"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 15px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }
        .error {
            color: red;
            margin: 10px 0;
        }
        #resume_field {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form action="/formcontroller/submit" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <h1>Registration Form</h1>

        <?php if (isset($validation)): ?>
            <div class="error">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>

        <label for="full_name">Full Name:</label>
        <input type="text" name="full_name" id="full_name" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" maxlength="10" required>

        <label>Gender:</label>
        <input type="radio" name="gender" value="male" required> Male
        <input type="radio" name="gender" value="female" required> Female

        <label for="dob">Date of Birth:</label>
        <input type="date" name="dob" id="dob" required>

        <label for="profile_photo">Profile Photo:</label>
        <input type="file" name="profile_photo" id="profile_photo" accept=".jpg,.png" required>

        <label>
            <input type="checkbox" name="checkbox" id="checkbox" value="job_search"> Job Search / E-Learning
        </label>

        <div id="resume_field" style="display:none;">
            <label for="resume">Upload Resume:</label>
            <input type="file" name="resume" id="resume" accept=".pdf,.doc">
        </div>

        <label for="skills">Skills:</label>
        <select name="skills[]" id="skills" multiple required>
            <option value="html">HTML</option>
            <option value="css">CSS</option>
            <option value="react">React</option>
            <option value="javascript">JavaScript</option>
            <option value="php">PHP</option>
            <option value="node">Node</option>
            <option value="ajax">AJAX</option>
        </select>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" id="confirm_password" required>

        <input type="submit" value="Submit">
    </form>

    <script>
        $(document).ready(function() {
            $('#checkbox').change(function() {
                if ($(this).is(':checked')) {
                    $('#resume_field').show();
                } else {
                    $('#resume_field').hide();
                }
            });
        });
    </script>
</body>
</html>
