<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class User extends Controller
{
    public function index()
    {
        return view('user_form');
    }

    public function submit()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'full_name' => 'required',
            'email' => 'required|valid_email',
            'phone' => 'required|regex_match[/^\d{10}$/]',
            'gender' => 'required',
            'dob' => 'required',
            'profile_photo' => 'uploaded[profile_photo]|max_size[profile_photo,4096]|is_image[profile_photo]|mime_in[profile_photo,image/jpg,image/jpeg,image/png]',
            'skills' => 'required',
            'password' => 'required|min_length[8]|regex_match[/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}/]',
            'confirm_password' => 'required|matches[password]',
            'resume_upload' => 'if_exist|uploaded[resume_upload]|mime_in[resume_upload,application/pdf,application/msword]',
        ];

        if (!$this->validate($rules)) {
            return view('user_form', [
                'validation' => $this->validator
            ]);
        }

        $userModel = new UserModel();

        $data = [
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'dob' => $this->request->getPost('dob'),
            'skills' => implode(',', $this->request->getPost('skills')),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        if ($this->request->getFile('profile_photo')->isValid()) {
            $profilePhoto = $this->request->getFile('profile_photo');
            $profilePhoto->move(WRITEPATH . 'uploads');
            $data['profile_photo'] = $profilePhoto->getName();
        }

        if ($this->request->getPost('job_search')) {
            if ($this->request->getFile('resume_upload')->isValid()) {
                $resumeUpload = $this->request->getFile('resume_upload');
                $resumeUpload->move(WRITEPATH . 'uploads');
                $data['resume_upload'] = $resumeUpload->getName();
            }
        }

        $userModel->save($data);

        return redirect()->to('/')->with('message', 'Form submitted successfully!');
    }
}
