<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class FormController extends Controller
{
    public function index()
    {
        return view('form_view');
    }

    public function submit()
    {
        helper(['form', 'url']);

        $rules = [
            'full_name' => 'required',
            'email' => 'required|valid_email',
            'phone' => 'required|numeric|max_length[10]',
            'gender' => 'required',
            'dob' => 'required',
            'profile_photo' => 'uploaded[profile_photo]|mime_in[profile_photo,image/jpg,image/jpeg,image/png]',
            'checkbox' => 'required',
            'skills' => 'required',
            'resume' => 'if_in[checkbox,job_search]|uploaded[resume]|mime_in[resume,application/pdf,application/msword]',
            'password' => 'required|min_length[8]|regex_match[/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}/]',
            'confirm_password' => 'matches[password]',
        ];

        if (!$this->validate($rules)) {
            return view('form_view', ['validation' => $this->validator]);
        }

        $model = new UserModel();

        $profilePhoto = $this->request->getFile('profile_photo');
        $profilePhoto->move(WRITEPATH . 'uploads', $profilePhoto->getName());
        
        $resume = $this->request->getFile('resume');
        if ($resume) {
            $resume->move(WRITEPATH . 'uploads', $resume->getName());
        }

        $model->save([
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'gender' => $this->request->getPost('gender'),
            'dob' => $this->request->getPost('dob'),
            'profile_photo' => $profilePhoto->getName(),
            'checkbox' => $this->request->getPost('checkbox'),
            'skills' => implode(',', $this->request->getPost('skills')),
            'resume' => $resume ? $resume->getName() : null,
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ]);

        return redirect()->to('/success');
    }
}
