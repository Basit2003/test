<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'full_name', 'email', 'phone', 'gender', 'dob', 'profile_photo', 'checkbox', 'skills', 'resume', 'password'
    ];
}
